function setup() {

  createCanvas(300, 300);

  strokeWeight(5);

  background(15);

}



function draw() {

  stroke(random(200), random(15), random(200));

  rect(random(width), random(height),
random(width), random(height));

}